public interface ConvolutionStrategy {
    void applyConvolution(int[][] F, int[][] V, int[][] C, int n, int m, int k);
}
